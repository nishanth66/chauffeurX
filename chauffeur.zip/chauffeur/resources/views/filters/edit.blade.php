@extends('layouts.app')

@section('content')
    <section class="content-header">
        <h1>
            Filter
        </h1>
   </section>
   <div class="content">
       @include('adminlte-templates::common.errors')
       <div class="box box-primary">
           <div class="box-body">
               <div class="row">
                   {!! Form::model($filter, ['route' => ['filters.update', $filter->id], 'method' => 'patch']) !!}

                        @include('filters.fields')

                   {!! Form::close() !!}
               </div>
           </div>
       </div>
   </div>
@endsection