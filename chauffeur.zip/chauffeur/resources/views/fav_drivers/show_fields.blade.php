<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $favDriver->id !!}</p>
</div>

<!-- Userid Field -->
<div class="form-group">
    {!! Form::label('userid', 'Userid:') !!}
    <p>{!! $favDriver->userid !!}</p>
</div>

<!-- Driverid Field -->
<div class="form-group">
    {!! Form::label('driverid', 'Driverid:') !!}
    <p>{!! $favDriver->driverid !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $favDriver->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $favDriver->updated_at !!}</p>
</div>

