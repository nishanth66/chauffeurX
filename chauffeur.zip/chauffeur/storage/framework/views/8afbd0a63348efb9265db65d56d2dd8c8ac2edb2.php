<!-- Category Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('category', 'Category:'); ?>

    <select class="form-control" name="category" id="category">
        <option value="" selected disabled>Select a Category</option>
        <?php if(isset($price) && $price->category != ''): ?>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>" <?php if ($price->category == $category->id) { echo "selected"; } ?>><?php echo e($category->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>

<!-- Amount Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('amount', 'Amount per Kilometer:'); ?>

    <?php echo Form::text('amount', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('prices.index'); ?>" class="btn btn-default">Cancel</a>
</div>
