<table class="table table-responsive" id="passengerApis-table">
    <thead>
        <tr>
            <th>Sl No</th>
            <th>Name</th>
            <th>Link</th>
            <th>Method</th>
            <th>Parameters</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
    <?php
        $i =1;
    ?>
    <?php $__currentLoopData = $passengerApis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $passengerApi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($i); ?></td>
            <td><?php echo $passengerApi->name; ?></td>
            <td><?php echo $passengerApi->link; ?></td>
            <td><?php echo $passengerApi->method; ?></td>
            <td><?php echo $passengerApi->parameters; ?></td>
            <td>
                <?php echo Form::open(['route' => ['passengerApis.destroy', $passengerApi->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('passengerApis.show', [$passengerApi->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('passengerApis.edit', [$passengerApi->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
        <?php
           $i++;
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>