<table class="table table-responsive" id="prices-table">
    <thead>
        <tr>
            <th>Category</th>
            <th>Amount</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $category = \App\Models\categories::whereId($price->category)->first();
        ?>
        <tr>
            <td><?php echo $category->name; ?></td>
            <td><?php echo $price->amount; ?></td>
            <td>
                <?php echo Form::open(['route' => ['prices.destroy', $price->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('prices.show', [$price->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('prices.edit', [$price->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>