<!-- Name Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<!-- Link Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('link', 'Link:'); ?>

    <?php echo Form::text('link', null, ['class' => 'form-control']); ?>

</div>

<!-- Method Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('method', 'Method:'); ?>

    <?php echo Form::text('method', null, ['class' => 'form-control']); ?>

</div>

<!-- Parameters Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('parameters', 'Parameters:'); ?>

    <?php if(isset($passengerApi) && $passengerApi->parameters): ?>
        <textarea name="parameters" class="form-control" cols="50" rows="5"><?php echo e($passengerApi->parameters); ?></textarea>
    <?php else: ?>
        <textarea name="parameters" class="form-control" cols="50" rows="5"></textarea>
    <?php endif; ?>
</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('passengerApis.index'); ?>" class="btn btn-default">Cancel</a>
</div>
