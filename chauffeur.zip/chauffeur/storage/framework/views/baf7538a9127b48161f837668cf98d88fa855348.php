<table class="table table-responsive" id="categories-table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Description</th>
            <th>Image</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $categories->name; ?></td>
            <td><?php echo $categories->description; ?></td>
            <td>
                <?php if(isset($categories->image)): ?>
                    <img src="<?php echo e(asset('public/avatars').'/'.$categories->image); ?>" class="show-image">
                <?php else: ?>
                    <img src="<?php echo e(asset('public/image/default.png')); ?>" class="show-image">
                <?php endif; ?>
            </td>
            <td>
                <?php echo Form::open(['route' => ['categories.destroy', $categories->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('categories.show', [$categories->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('categories.edit', [$categories->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>