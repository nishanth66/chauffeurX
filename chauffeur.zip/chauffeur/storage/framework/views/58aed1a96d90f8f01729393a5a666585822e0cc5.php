<!-- Amount Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('amount', 'Amount:'); ?>

    <?php echo Form::text('amount', null, ['class' => 'form-control']); ?>

</div>

<!-- Terms Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('terms', 'Terms:'); ?>

    <?php echo Form::text('terms', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('cencellations.index'); ?>" class="btn btn-default">Cancel</a>
</div>
