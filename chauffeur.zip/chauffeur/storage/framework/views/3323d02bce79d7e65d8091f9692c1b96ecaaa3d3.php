<!-- Name Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control','placeholder'=>'Category Description']); ?>

</div>

<!-- Description Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('description', 'Description:'); ?>

    <?php if(isset($categories) && $categories != ''): ?>
        <textarea class="form-control" name="description" cols="50" rows="5"><?php echo e($categories->description); ?></textarea>
    <?php else: ?>
        <textarea class="form-control" name="description" cols="50" rows="5"></textarea>
    <?php endif; ?>
</div>

<!-- Image Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('image', 'Image:'); ?>

    <input type="file" class="form-control" name="image" placeholder="Category Image" onchange="readURL(this)"> <br/>
    <div id="image">
        <?php if(isset($categories) && $categories != ''): ?>
            <?php if(isset($categories->image)): ?>
                <img src="<?php echo e(asset('public/avatars').'/'.$categories->image); ?>" class="show-image">
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('categories.index'); ?>" class="btn btn-default">Cancel</a>
</div>

    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    var html = '<br/><img class="show-image" src="' + e.target.result + '">';
                    $('#image')
                        .html(html);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
