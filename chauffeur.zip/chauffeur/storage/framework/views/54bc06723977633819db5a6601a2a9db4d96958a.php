<li class="<?php echo e(Request::is('cencellations*') ? 'active' : ''); ?>">
    <a href="<?php echo url('cencellations'); ?>"><i class="fa fa-gift"></i><span>Cancellation</span></a>
</li>

<li class="<?php echo e(Request::is('categories*') ? 'active' : ''); ?>">
    <a href="<?php echo route('categories.index'); ?>"><i class="fa fa-list-alt"></i><span>Categories</span></a>
</li>


<li class="<?php echo e(Request::is('prices*') ? 'active' : ''); ?>">
    <a href="<?php echo route('prices.index'); ?>"><i class="fa fa-money"></i><span>Prices</span></a>
</li>

<li class="<?php echo e(Request::is('passengerApis*') ? 'active' : ''); ?>">
    <a href="<?php echo route('passengerApis.index'); ?>"><i class="fa fa-edit"></i><span>Passenger Apis</span></a>
</li>

<li class="<?php echo e(Request::is('advertisements*') ? 'active' : ''); ?>">
    <a href="<?php echo route('advertisements.index'); ?>"><i class="fa fa-edit"></i><span>Advertisements</span></a>
</li>

