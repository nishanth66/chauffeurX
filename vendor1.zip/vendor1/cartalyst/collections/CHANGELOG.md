# Collections Change Log

This project follows [Semantic Versioning](CONTRIBUTING.md).

## Proposals

We do not give estimated times for completion on `Accepted` Proposals.

- [Accepted](https://github.com/cartalyst/collections/labels/Accepted)
- [Rejected](https://github.com/cartalyst/collections/labels/Rejected)

---

#### v1.1.0 - 2015-03-06

`ADDED`

- Added a `sum` method.
- Added a `lists` method.

#### v1.0.0 - 2015-02-18

`INIT`

- Added a Collection class.
